"""
TensorFlow ML Stock Intelligence Service
==========================================
Runs on SEPARATE PORT (8001) — does NOT affect the main app on port 8000.

Architecture:
  ┌────────────────────────────────────────────────────────────┐
  │  MAIN APP (:8000)              ML SERVICE (:8001)          │
  │  ┌──────────────────┐          ┌──────────────────────┐   │
  │  │ Chartink Watcher │──HTTP──→ │ /ingest/chartink     │   │
  │  │ (5-min poll)     │          │ (receives signals)   │   │
  │  └──────────────────┘          │                      │   │
  │  ┌──────────────────┐          │ Background Learner   │   │
  │  │ EMA9 Screener    │──HTTP──→ │ (APScheduler:        │   │
  │  │ (F&O stocks)     │          │  - Fine-tune 30min   │   │
  │  └──────────────────┘          │  - Download data     │   │
  │                                │  - Track outcomes)   │   │
  │                                │                      │   │
  │                                │ TensorFlow Models    │   │
  │                                │ ┌──────────────────┐ │   │
  │                                │ │ SignalQuality    │ │   │
  │                                │ │ TrendRegime      │ │   │
  │                                │ │ ReturnForecaster │ │   │
  │                                │ │ RiskEstimator    │ │   │
  │                                │ └──────────────────┘ │   │
  │                                │                      │   │
  │                                │ API Endpoints:       │   │
  │                                │ GET /predict/{ticker}│   │
  │                                │ POST /predict/batch │   │
  │                                │ GET /decisions      │   │
  │                                │ POST /ingest/chartink│  │
  │                                │ GET /status         │   │
  │                                │ POST /train/trigger │   │
  │                                │ GET /dashboard      │   │
  │                                └──────────────────────┘   │
  └────────────────────────────────────────────────────────────┘

Run:  python ml_service.py
      or  uvicorn ml_service:app --host 0.0.0.0 --port 8001 --reload
"""

import os
import sys
import json
import time
import math
import logging
import threading
import asyncio
import datetime as dt
from pathlib import Path
from typing import Dict, List, Optional, Any

import numpy as np
import pandas as pd
import yfinance as yf

from fastapi import FastAPI, HTTPException, BackgroundTasks
from fastapi.staticfiles import StaticFiles
from fastapi.responses import HTMLResponse, JSONResponse
from fastapi.middleware.cors import CORSMiddleware
from pydantic import BaseModel

from apscheduler.schedulers.background import BackgroundScheduler
import pytz

# ── Ensure ml_service modules are importable ──
sys.path.insert(0, os.path.dirname(__file__))

# ── Optional ML model imports (graceful fallback to intelligent scoring) ──
HAS_ML_MODELS = False
try:
    from ml_features import extract_features, FEATURE_NAMES, FEATURE_STATS
    from ml_models import model_manager
    HAS_ML_MODELS = True
except ImportError as e:
    import logging as _logging
    _log = _logging.getLogger("ml_service")
    _log.warning(f"[Startup] ML modules not found ({e}), using Intelligent Scoring fallback.")
    # ── Stub fallbacks so every endpoint still works ──
    extract_features = None
    FEATURE_NAMES: List[str] = []
    FEATURE_STATS: Dict = {}

    class _StubModelManager:
        """Fallback that delegates to intelligent scoring when TF models are absent."""
        def __init__(self):
            self.models = {"signal_quality": None, "trend_regime": None, "return_forecaster": None, "risk_estimator": None}
            self.is_training = False
            self.total_training_samples = 0

        def predict(self, df):
            try:
                from intelligent_scoring import compute_intelligent_score
                result = compute_intelligent_score(df)
            except Exception:
                result = {"signal_quality": 0.5, "trend_regime": "SIDEWAYS", "expected_return": 0, "max_drawdown": -5, "risk_reward_ratio": 1.0, "ml_score": 50, "components": {}, "scoring_method": "intelligent_v2_fallback"}
            return result

        def predict_batch(self, ticker_dfs: Dict[str, pd.DataFrame]) -> Dict[str, Dict]:
            try:
                from intelligent_scoring import compute_intelligent_score
            except Exception:
                return {}
            results = {}
            for ticker, df in ticker_dfs.items():
                try:
                    results[ticker] = compute_intelligent_score(df)
                except Exception:
                    pass
            return results

        def get_status(self):
            return {"models_trained": 0, "total_samples": 0, "scoring_method": "intelligent_v2 (no TF models)"}

        def train_initial(self, *args, **kwargs):
            pass

        def fine_tune(self, *args, **kwargs):
            pass

        def _save_models(self):
            pass

    model_manager = _StubModelManager()

from ml_stock_analyzer import analyze_stock, scan_stocks_for_3pct

# ═══════════════════════════════════════════════════════════════════════════
#  CONFIGURATION
# ═══════════════════════════════════════════════════════════════════════════
BASE_DIR = Path(__file__).parent
DATA_DIR = BASE_DIR / "data"
MODELS_DIR = BASE_DIR / "models"
os.makedirs(DATA_DIR, exist_ok=True)
os.makedirs(MODELS_DIR, exist_ok=True)

IST = pytz.timezone("Asia/Kolkata")

CONFIG_FILE = BASE_DIR / "ml_config.json"
DEFAULT_CONFIG = {
    "fine_tune_interval_min": 30,
    "data_download_interval_min": 60,
    "target_tickers": [],  # if empty, auto-detect from main app
    "main_app_url": "http://localhost:8000",
    "target_pct": 3.0,
    "lookahead_days": 5,
    "min_data_bars": 200,
    "max_training_tickers": 100,
    "auto_train_on_startup": True,
    "chartink_auto_ingest": True,
    "chartink_poll_interval_min": 5,
}

def load_config() -> dict:
    cfg = DEFAULT_CONFIG.copy()
    if CONFIG_FILE.exists():
        try:
            with open(CONFIG_FILE) as f:
                cfg.update(json.load(f))
        except Exception:
            pass
    return cfg

def save_config(cfg: dict):
    with open(CONFIG_FILE, "w") as f:
        json.dump(cfg, f, indent=2)

config = load_config()

# ═══════════════════════════════════════════════════════════════════════════
#  LOGGING
# ═══════════════════════════════════════════════════════════════════════════
logging.basicConfig(
    level=logging.INFO,
    format="%(asctime)s [%(levelname)s] %(name)s: %(message)s",
    datefmt="%H:%M:%S",
)
logger = logging.getLogger("ml_service")

if HAS_ML_MODELS:
    logger.info("[Startup] TensorFlow ML models loaded successfully.")

# ═══════════════════════════════════════════════════════════════════════════
#  DATA STORE
# ═══════════════════════════════════════════════════════════════════════════
# In-memory store for the latest predictions and ingested Chartink signals
_prediction_cache: Dict[str, Dict] = {}  # ticker → prediction dict
_chartink_signals: List[Dict] = []       # latest ingested signals
_chartink_lock = threading.Lock()
_ml_decisions: List[Dict] = []           # ML-generated decisions
_training_log: List[Dict] = []           # training history
_decisions_lock = threading.Lock()

DECISIONS_FILE = DATA_DIR / "ml_decisions.json"
SIGNALS_FILE = DATA_DIR / "chartink_signals.json"


def _save_decisions():
    with _decisions_lock:
        with open(DECISIONS_FILE, "w") as f:
            json.dump(_ml_decisions[-500:], f, indent=2, default=str)


def _save_signals():
    with _chartink_lock:
        with open(SIGNALS_FILE, "w") as f:
            json.dump(_chartink_signals[-500:], f, indent=2, default=str)


# ═══════════════════════════════════════════════════════════════════════════
#  DATA DOWNLOAD (yfinance — same pattern as ema9_router)
# ═══════════════════════════════════════════════════════════════════════════
_yf_cache: Dict[str, Dict] = {}  # ticker → {"df": DataFrame, "ts": float}
_yf_lock = threading.Lock()
YF_CACHE_TTL = 4 * 3600  # 4 hours


def download_ticker_data(ticker: str, period: str = "10y") -> Optional[pd.DataFrame]:
    """Download OHLCV for a single ticker with caching."""
    cache_key = f"{ticker}:{period}"

    with _yf_lock:
        entry = _yf_cache.get(cache_key)
        if entry and (time.time() - entry["ts"]) < YF_CACHE_TTL:
            return entry["df"].copy()

    for suffix in [".NS", ".BO"]:
        try:
            t = yf.Ticker(f"{ticker}{suffix}")
            hist = t.history(period=period, auto_adjust=True)
            if hist is not None and not hist.empty and len(hist) >= 100:
                df = hist[["Open", "High", "Low", "Close", "Volume"]].copy()
                df = df.dropna(how="all")
                with _yf_lock:
                    _yf_cache[cache_key] = {"df": df, "ts": time.time()}
                return df.copy()
        except Exception:
            continue
    return None


def download_tickers_batch(tickers: List[str]) -> Dict[str, pd.DataFrame]:
    """Download data for multiple tickers with rate limiting."""
    result = {}
    for i, ticker in enumerate(tickers):
        df = download_ticker_data(ticker)
        if df is not None:
            result[ticker] = df
        if i < len(tickers) - 1:
            time.sleep(0.15)  # yfinance rate limit
    logger.info(f"[Data] Downloaded {len(result)}/{len(tickers)} tickers")
    return result


def get_fno_tickers() -> List[str]:
    """Load F&O ticker list (same source as main app)."""
    csv_path = os.path.join(os.path.dirname(BASE_DIR), "data", "tickers.csv")
    if not os.path.exists(csv_path):
        csv_path = os.path.join(os.path.dirname(BASE_DIR), "tickers.csv")

    if os.path.exists(csv_path):
        try:
            df = pd.read_csv(csv_path, dtype=str)
            col = "SYMBOL" if "SYMBOL" in df.columns else "symbol"
            if col in df.columns:
                tickers = [s.strip().upper() for s in df[col].dropna() if s.strip()]
                return tickers[:200]  # cap for ML training
        except Exception:
            pass

    # Fallback: popular F&O stocks
    return [
        "RELIANCE", "HDFCBANK", "ICICIBANK", "INFY", "TCS", "HINDUNILVR",
        "ITC", "SBIN", "BHARTIARTL", "KOTAKBANK", "LT", "AXISBANK",
        "ASIANPAINT", "BAJFINANCE", "MARUTI", "TITAN", "SUNPHARMA",
        "TATAMOTORS", "WIPRO", "HCLTECH", "ULTRACEMCO", "NESTLEIND",
        "NTPC", "POWERGRID", "ADANIENT", "ADANIPORTS", "TECHM",
        "ONGC", "COALINDIA", "JSWSTEEL", "TATASTEEL", "HINDALCO",
    ]


# ═══════════════════════════════════════════════════════════════════════════
#  CHARTINK INTEGRATION — Pull signals from main app
# ═══════════════════════════════════════════════════════════════════════════

async def _fetch_chartink_from_main() -> List[Dict]:
    """
    Fetch the latest Chartink screener results from the main app (port 8000).
    This is the BRIDGE between the two services.
    """
    import httpx
    url = f"{config['main_app_url']}/api/chartink-screener/today-primes"
    try:
        async with httpx.AsyncClient(timeout=15.0) as client:
            resp = await client.get(url)
            if resp.status_code == 200:
                data = resp.json()
                return data.get("primes", data.get("results", {}).get("prime_targets", []))
    except Exception as e:
        logger.warning(f"[Chartink] Failed to fetch from main app: {e}")
    return []


async def _fetch_ema9_signals_from_main() -> List[Dict]:
    """Fetch latest EMA9 screener signals from main app."""
    import httpx
    url = f"{config['main_app_url']}/api/ema9/quick-scan"
    try:
        async with httpx.AsyncClient(timeout=30.0) as client:
            resp = await client.get(url)
            if resp.status_code == 200:
                data = resp.json()
                return data.get("prime_targets", [])
    except Exception as e:
        logger.warning(f"[EMA9] Failed to fetch from main app: {e}")
    return []


# ═══════════════════════════════════════════════════════════════════════════
#  INTELLIGENT DECISION ENGINE
# ═══════════════════════════════════════════════════════════════════════════

def _generate_decisions(signals: List[Dict], predictions: Dict[str, Dict]) -> List[Dict]:
    """
    Combine Chartink/EMA9 signals with ML predictions to generate
    intelligent trading decisions based on the user's EMA9 strategy.
    """
    decisions = []

    for signal in signals:
        ticker = signal.get("ticker", "")
        if not ticker:
            continue

        ml_pred = predictions.get(ticker, {})
        ml_score = ml_pred.get("ml_score", 0)
        signal_quality = ml_pred.get("signal_quality", 0.5)
        regime = ml_pred.get("trend_regime", "SIDEWAYS")
        expected_return = ml_pred.get("expected_return", 0)
        max_drawdown = ml_pred.get("max_drawdown", 0)
        risk_reward = ml_pred.get("risk_reward_ratio", 0)

        # Strategy-aligned decision logic
        # Your EMA9 strategy: buy on 9EMA crossover confirmation, target 3%, stop below 9EMA
        # ML enhances this by:
        #   1. Filtering out low-quality signals (signal_quality < 0.4)
        #   2. Sizing based on risk_reward_ratio
        #   3. Warning about regime mismatch (signal in DOWNTREND)
        #   4. Suggesting target adjustments based on expected_return

        entry_price = signal.get("current_price") or signal.get("entry_price") or signal.get("confirm_close")
        target_price = signal.get("target_3pct") or signal.get("target_price")

        # Support proximity from signal
        near_support = signal.get("near_support", False)
        support_level = signal.get("near_support_level")
        support_touches = signal.get("near_support_touches", 0)

        # FV gap from signal
        fv_gap = signal.get("gap_to_fair_pct", signal.get("fair_gap_pct"))
        is_undervalued = fv_gap is not None and fv_gap > 0

        # Pullback context
        is_pullback = signal.get("is_pullback", False)
        pullback_dist = signal.get("pullback_dist_pct", 0)

        # ── DECISION MATRIX ──
        reasons = []
        confidence = ml_score / 100.0
        action = "HOLD"

        # Boost: high signal quality + uptrend
        if signal_quality > 0.6 and regime == "UPTREND":
            action = "BUY"
            confidence = min(0.95, confidence * 1.2)
            reasons.append(f"High signal quality ({signal_quality:.0%}) in {regime}")

        # Boost: near multi-touch support
        if near_support and support_touches >= 3:
            confidence = min(0.95, confidence * 1.1)
            reasons.append(f"Near {support_touches}-touch support at {support_level}")

        # Boost: undervalued (below fair value)
        if is_undervalued:
            confidence = min(0.95, confidence * 1.1)
            reasons.append(f"Undervalued by {fv_gap:.1f}%")

        # Boost: pullback entry (your strategy loves pullbacks)
        if is_pullback and pullback_dist >= 10:
            confidence = min(0.95, confidence * 1.15)
            reasons.append(f"Pullback entry ({pullback_dist:.1f}% from prior high)")

        # Reduce: downtrend regime
        if regime == "DOWNTREND":
            if action == "BUY":
                action = "HOLD"
            reasons.append(f"WARNING: DOWNTREND regime — signal likely to fail")

        # Reduce: low signal quality
        if signal_quality < 0.4:
            action = "SKIP"
            reasons.append(f"Low signal quality ({signal_quality:.0%}) — skip to preserve capital")

        # Reduce: poor risk/reward
        if risk_reward < 0.8:
            if action == "BUY":
                action = "HOLD"
            reasons.append(f"Poor risk:reward ({risk_reward:.1f}x)")

        # Skip: very high expected drawdown
        if max_drawdown < -5:
            action = "SKIP"
            reasons.append(f"High expected drawdown ({max_drawdown:.1f}%) — risk too high")

        # Final: STRONG BUY if all conditions align
        if action == "BUY" and confidence > 0.75 and len(reasons) >= 3:
            action = "STRONG_BUY"

        # Target suggestion based on ML expected return
        suggested_target_pct = config.get("target_pct", 3.0)
        if expected_return > 0 and expected_return < suggested_target_pct:
            suggested_target_pct = max(2.0, round(expected_return * 0.8, 1))
            reasons.append(f"ML suggests adjusting target to {suggested_target_pct}% (expected return: {expected_return:.1f}%)")

        # Position sizing suggestion (based on risk_reward and confidence)
        # Higher confidence + better R:R = larger position
        if risk_reward > 0 and confidence > 0:
            position_score = confidence * min(risk_reward, 3.0) / 3.0
            if position_score > 0.6:
                suggested_size = "LARGE (3-5% of capital)"
            elif position_score > 0.35:
                suggested_size = "MEDIUM (2-3% of capital)"
            else:
                suggested_size = "SMALL (1% of capital)"
        else:
            suggested_size = "SKIP"

        decision = {
            "ticker": ticker,
            "action": action,
            "confidence": round(confidence * 100, 1),
            "ml_score": ml_score,
            "signal_quality": signal_quality,
            "trend_regime": regime,
            "expected_return_pct": expected_return,
            "max_drawdown_pct": max_drawdown,
            "risk_reward_ratio": risk_reward,
            "entry_price": entry_price,
            "target_price": target_price,
            "suggested_target_pct": suggested_target_pct,
            "suggested_position_size": suggested_size,
            "reasons": reasons,
            "near_support": near_support,
            "support_level": support_level,
            "is_undervalued": is_undervalued,
            "is_pullback": is_pullback,
            "timestamp": dt.datetime.now(IST).strftime("%Y-%m-%d %H:%M:%S"),
        }
        decisions.append(decision)

    # Sort by confidence descending
    decisions.sort(key=lambda d: d["confidence"], reverse=True)
    return decisions


# ═══════════════════════════════════════════════════════════════════════════
#  BACKGROUND SCHEDULER TASKS
# ═══════════════════════════════════════════════════════════════════════════

def _is_market_open() -> bool:
    now = dt.datetime.now(IST)
    if now.weekday() >= 5:
        return False
    o = now.replace(hour=9, minute=15, second=0, microsecond=0)
    c = now.replace(hour=15, minute=30, second=0, microsecond=0)
    return o <= now <= c


def _background_fine_tune():
    """Scheduled fine-tuning task — runs every 30 minutes."""
    if model_manager.is_training:
        return

    tickers = get_fno_tickers()[:config.get("max_training_tickers", 100)]
    if not tickers:
        return

    ticker_dfs = download_tickers_batch(tickers)
    if ticker_dfs:
        start = time.time()
        model_manager.fine_tune(ticker_dfs, target_pct=config["target_pct"], epochs=3)
        elapsed = time.time() - start

        log_entry = {
            "timestamp": dt.datetime.now(IST).strftime("%Y-%m-%d %H:%M:%S"),
            "type": "fine_tune",
            "tickers_used": len(ticker_dfs),
            "elapsed_seconds": round(elapsed, 1),
            "total_samples": model_manager.total_training_samples,
        }
        _training_log.append(log_entry)
        logger.info(f"[Scheduler] Fine-tune complete: {len(ticker_dfs)} tickers, {elapsed:.1f}s")


async def _background_chartink_ingest():
    """Fetch Chartink signals from main app and run ML predictions."""
    if not config.get("chartink_auto_ingest", True):
        return

    # Fetch signals from main app
    chartink_primes = await _fetch_chartink_from_main()
    ema9_signals = await _fetch_ema9_signals_from_main()

    # Merge (deduplicate by ticker)
    all_signals = {}
    for s in chartink_primes:
        t = s.get("ticker", "")
        if t:
            all_signals[t] = s
    for s in ema9_signals:
        t = s.get("ticker", "")
        if t:
            all_signals[t] = s

    if not all_signals:
        return

    # Download data and predict
    tickers = list(all_signals.keys())
    ticker_dfs = download_tickers_batch(tickers)

    # Run ML predictions
    predictions = model_manager.predict_batch(ticker_dfs)

    # Update prediction cache
    for ticker, pred in predictions.items():
        _prediction_cache[ticker] = pred

    # Generate intelligent decisions
    signal_list = list(all_signals.values())
    decisions = _generate_decisions(signal_list, predictions)

    # Store
    with _decisions_lock:
        _ml_decisions.extend(decisions)
        # Keep only last 500 decisions
        if len(_ml_decisions) > 500:
            _ml_decisions[:] = _ml_decisions[-500:]

    with _chartink_lock:
        _chartink_signals[:] = signal_list[-200:]

    _save_decisions()
    _save_signals()

    logger.info(f"[Ingest] Processed {len(signal_list)} signals, generated {len(decisions)} decisions")


# ═══════════════════════════════════════════════════════════════════════════
#  FASTAPI APPLICATION
# ═══════════════════════════════════════════════════════════════════════════
app = FastAPI(
    title="TensorFlow ML Stock Intelligence",
    description="ML-powered stock analysis service — runs alongside your EMA9 screener",
    version="1.0.0",
)

app.add_middleware(
    CORSMiddleware,
    allow_origins=["*"],
    allow_methods=["*"],
    allow_headers=["*"],
)

scheduler = BackgroundScheduler()


# ─────────────────────────────────────────────────────────────────
#  STARTUP
# ─────────────────────────────────────────────────────────────────
@app.on_event("startup")
async def startup_event():
    logger.info("=" * 60)
    logger.info("  TensorFlow ML Stock Intelligence Service starting...")
    logger.info(f"  Port: 8001 | Main app: {config['main_app_url']}")
    logger.info("=" * 60)

    # Schedule background fine-tuning
    scheduler.add_job(
        _background_fine_tune,
        trigger="interval",
        minutes=config.get("fine_tune_interval_min", 30),
        id="fine_tune",
        replace_existing=True,
    )

    # Schedule Chartink ingestion
    scheduler.add_job(
        lambda: asyncio.run(_background_chartink_ingest()),
        trigger="interval",
        minutes=config.get("chartink_poll_interval_min", 5),
        id="chartink_ingest",
        replace_existing=True,
    )

    scheduler.start()
    logger.info(f"[Scheduler] Started: fine-tune every {config['fine_tune_interval_min']}min, "
                f"Chartink ingest every {config['chartink_poll_interval_min']}min")

    # Auto-train on startup if no models exist (skip when using intelligent scoring fallback)
    if HAS_ML_MODELS and config.get("auto_train_on_startup", True):
        any_trained = any(m is not None for m in model_manager.models.values())
        if not any_trained:
            logger.info("[Startup] No trained models found — triggering initial training...")
            tickers = get_fno_tickers()[:config.get("max_training_tickers", 100)]
            ticker_dfs = download_tickers_batch(tickers)
            if ticker_dfs:
                model_manager.train_initial(ticker_dfs, target_pct=config["target_pct"])
    elif not HAS_ML_MODELS:
        logger.info("[Startup] Running in Intelligent Scoring mode — skipping ML model training.")


@app.on_event("shutdown")
def shutdown_event():
    scheduler.shutdown(wait=False)
    model_manager._save_models()
    logger.info("[Shutdown] Models saved, scheduler stopped.")


# ═══════════════════════════════════════════════════════════════════════════
#  API ENDPOINTS
# ═══════════════════════════════════════════════════════════════════════════

# ── Request / Response Models ──
class PredictRequest(BaseModel):
    tickers: List[str]
    enrich_with_strategy: bool = True


class IngestRequest(BaseModel):
    signals: List[Dict]
    source: str = "chartink"


class TrainRequest(BaseModel):
    tickers: Optional[List[str]] = None
    epochs: int = 10
    target_pct: float = 3.0


# ─────────────────────────────────────────────────────────────────
#  PREDICTION ENDPOINTS
# ─────────────────────────────────────────────────────────────────

@app.get("/api/predict/{ticker}")
async def predict_ticker(ticker: str):
    """
    Get ML predictions for a single ticker.
    Returns signal quality, trend regime, expected return, risk estimate,
    and an actionable decision.
    """
    ticker = ticker.strip().upper()
    df = download_ticker_data(ticker)
    if df is None or len(df) < 100:
        raise HTTPException(404, f"No sufficient data for {ticker}")

    prediction = model_manager.predict(df)
    prediction["ticker"] = ticker
    return prediction


@app.post("/api/predict/batch")
async def predict_batch(req: PredictRequest):
    """
    Get ML predictions for multiple tickers.
    Optionally enriches with strategy-aligned decisions.
    """
    tickers = [t.strip().upper() for t in req.tickers if t.strip()][:200]
    if not tickers:
        raise HTTPException(400, "No tickers provided")

    ticker_dfs = download_tickers_batch(tickers)
    predictions = model_manager.predict_batch(ticker_dfs)

    # Update cache
    for ticker, pred in predictions.items():
        _prediction_cache[ticker] = pred

    return {
        "predictions": predictions,
        "count": len(predictions),
        "model_status": model_manager.get_status()["models_trained"],
    }


# ─────────────────────────────────────────────────────────────────
#  INTELLIGENT DECISIONS
# ─────────────────────────────────────────────────────────────────

@app.get("/api/decisions")
async def get_decisions(limit: int = 20):
    """
    Get the latest ML-generated intelligent trading decisions.
    These combine your EMA9 strategy signals with ML predictions.
    """
    with _decisions_lock:
        decisions = _ml_decisions[-limit:]

    return {
        "decisions": decisions,
        "total_stored": len(_ml_decisions),
        "showing": len(decisions),
    }


@app.get("/api/decisions/summary")
async def get_decisions_summary():
    """
    Summary of current decisions: counts by action, top picks, etc.
    """
    with _decisions_lock:
        recent = _ml_decisions[-100:] if _ml_decisions else []

    if not recent:
        return {"message": "No decisions yet. Waiting for Chartink/EMA9 signals..."}

    action_counts = {}
    for d in recent:
        action = d["action"]
        action_counts[action] = action_counts.get(action, 0) + 1

    strong_buys = [d for d in recent if d["action"] == "STRONG_BUY"]
    buys = [d for d in recent if d["action"] == "BUY"]

    return {
        "total_decisions": len(recent),
        "action_distribution": action_counts,
        "strong_buys": strong_buys[:5],
        "top_buys": (strong_buys + buys)[:10],
        "avg_ml_score": round(np.mean([d["ml_score"] for d in recent]), 1) if recent else 0,
        "avg_signal_quality": round(np.mean([d["signal_quality"] for d in recent]), 3) if recent else 0,
    }


# ─────────────────────────────────────────────────────────────────
#  CHARTINK INGESTION
# ─────────────────────────────────────────────────────────────────

@app.post("/api/ingest/chartink")
async def ingest_chartink_signals(req: IngestRequest):
    """
    Manually push Chartink/EMA9 signals into the ML service.
    The service will download data, run predictions, and generate decisions.
    Normally this happens automatically via background polling.
    """
    signals = req.signals
    if not signals:
        raise HTTPException(400, "No signals provided")

    tickers = list({s.get("ticker", "") for s in signals if s.get("ticker")})
    if not tickers:
        raise HTTPException(400, "No valid tickers in signals")

    ticker_dfs = download_tickers_batch(tickers)
    predictions = model_manager.predict_batch(ticker_dfs)

    for ticker, pred in predictions.items():
        _prediction_cache[ticker] = pred

    decisions = _generate_decisions(signals, predictions)

    with _decisions_lock:
        _ml_decisions.extend(decisions)
        if len(_ml_decisions) > 500:
            _ml_decisions[:] = _ml_decisions[-500:]

    with _chartink_lock:
        _chartink_signals.extend(signals)
        if len(_chartink_signals) > 200:
            _chartink_signals[:] = _chartink_signals[-200:]

    _save_decisions()
    _save_signals()

    return {
        "ingested": len(signals),
        "predictions_generated": len(predictions),
        "decisions_generated": len(decisions),
        "source": req.source,
    }


@app.get("/api/ingest/chartink/auto-poll")
async def trigger_chartink_poll():
    """
    Manually trigger the Chartink ingestion cycle (normally runs on scheduler).
    """
    await _background_chartink_ingest()
    return {"status": "ok", "message": "Chartink poll triggered"}


# ─────────────────────────────────────────────────────────────────
#  TRAINING ENDPOINTS
# ─────────────────────────────────────────────────────────────────

@app.post("/api/train/trigger")
async def trigger_training(req: TrainRequest, background_tasks: BackgroundTasks):
    """
    Trigger model training (initial or fine-tune).
    Runs in the background to avoid blocking.
    """
    if model_manager.is_training:
        return {"status": "already_training", "message": "Training is in progress..."}

    def _do_train():
        tickers = req.tickers or get_fno_tickers()[:config.get("max_training_tickers", 100)]
        ticker_dfs = download_tickers_batch(tickers)
        if ticker_dfs:
            model_manager.train_initial(ticker_dfs, target_pct=req.target_pct)
            # Also fine-tune with specified epochs
            model_manager.fine_tune(ticker_dfs, target_pct=req.target_pct, epochs=req.epochs)

    background_tasks.add_task(_do_train)
    return {
        "status": "training_started",
        "tickers": req.tickers or f"auto ({config.get('max_training_tickers', 100)} F&O stocks)",
        "target_pct": req.target_pct,
    }


@app.get("/api/train/status")
async def training_status():
    """Get model training status and statistics."""
    return model_manager.get_status()


@app.get("/api/train/history")
async def training_history(limit: int = 20):
    """Get recent training log entries."""
    return {
        "history": _training_log[-limit:],
        "total": len(_training_log),
    }


# ─────────────────────────────────────────────────────────────────
#  FEATURE INSIGHTS
# ─────────────────────────────────────────────────────────────────

@app.get("/api/features/{ticker}")
async def get_features(ticker: str):
    """
    Get the raw feature vector for a ticker (useful for debugging/analysis).
    """
    ticker = ticker.strip().upper()
    df = download_ticker_data(ticker)
    if df is None or len(df) < 100:
        raise HTTPException(404, f"No data for {ticker}")

    if not HAS_ML_MODELS or extract_features is None:
        raise HTTPException(503, "Feature extraction requires ml_features module (TensorFlow models not available). Using intelligent scoring instead.")

    features = extract_features(df, normalize=False)
    feature_dict = {name: round(float(val), 4) for name, val in zip(FEATURE_NAMES, features)}
    return {
        "ticker": ticker,
        "features": feature_dict,
        "num_features": len(feature_dict),
        "data_bars": len(df),
    }


# ─────────────────────────────────────────────────────────────────
#  MODEL CONFIGURATION
# ─────────────────────────────────────────────────────────────────

@app.get("/api/config")
async def get_ml_config():
    """Get current ML service configuration."""
    return {
        "config": config,
        "feature_stats_available": len(FEATURE_STATS),
    }


@app.put("/api/config")
async def update_ml_config(new_config: dict):
    """Update ML service configuration."""
    global config
    config.update(new_config)
    save_config(config)
    return {"status": "updated", "config": config}


# ─────────────────────────────────────────────────────────────────
#  HEALTH / STATUS
# ─────────────────────────────────────────────────────────────────

@app.get("/api/health")
async def health():
    """Health check endpoint."""
    return {
        "status": "healthy",
        "service": "tensorflow-ml-stock-intelligence",
        "port": 8001,
        "scoring_mode": "tensorflow_ml" if HAS_ML_MODELS else "intelligent_scoring_fallback",
        "models_loaded": {k: v is not None for k, v in model_manager.models.items()},
        "prediction_cache_size": len(_prediction_cache),
        "decisions_stored": len(_ml_decisions),
        "chartink_signals": len(_chartink_signals),
        "scheduler_running": scheduler.running,
    }


# ─────────────────────────────────────────────────────────────────
#  PER-STOCK DEEP ANALYSIS (NEW — TensorFlow ML Individual Stock)
# ─────────────────────────────────────────────────────────────────

@app.get("/api/stock-analysis/{ticker}")
async def stock_deep_analysis(ticker: str):
    """
    Full per-stock deep analysis with TensorFlow ML.
    Downloads yfinance data, runs pattern recognition, behavior profiling,
    ML prediction, and generates 3% target strategy suggestion.
    """
    ticker = ticker.strip().upper()
    df = download_ticker_data(ticker)
    if df is None or len(df) < 100:
        raise HTTPException(404, f"No sufficient data for {ticker} — need at least 100 bars")

    # Get ML prediction
    ml_prediction = model_manager.predict(df)
    ml_prediction["ticker"] = ticker

    # Full analysis
    report = analyze_stock(ticker, df, ml_prediction=ml_prediction)
    return report


@app.post("/api/stock-analysis/batch")
async def stock_analysis_batch(background_tasks: BackgroundTasks):
    """
    Scan ALL F&O stocks with ML + pattern recognition for 3% target.
    Returns ranked list of best opportunities.
    This is the ML-powered equivalent of your Chartink screener.
    """
    tickers = get_fno_tickers()
    if not tickers:
        raise HTTPException(500, "No tickers available")

    # Download data
    ticker_dfs = download_tickers_batch(tickers)
    if not ticker_dfs:
        raise HTTPException(500, "Failed to download data for any ticker")

    # Run ML predictions
    ml_predictions = model_manager.predict_batch(ticker_dfs)

    # Scan with strategy engine
    results = scan_stocks_for_3pct(ticker_dfs, ml_predictions)

    return {
        "total_scanned": len(tickers),
        "data_available": len(ticker_dfs),
        "results": results,
        "strong_buys": len([r for r in results if r["strategy_action"] == "STRONG_BUY"]),
        "buys": len([r for r in results if r["strategy_action"] == "BUY"]),
        "watch": len([r for r in results if r["strategy_action"] == "WATCH"]),
        "wait": len([r for r in results if r["strategy_action"] == "WAIT"]),
        "scan_time": dt.datetime.now(IST).strftime("%Y-%m-%d %H:%M:%S"),
    }


@app.get("/api/stock-analysis/quick/{ticker}")
async def stock_quick_analysis(ticker: str):
    """
    Quick analysis — just ML prediction + basic strategy (no pattern deep dive).
    Faster than the full analysis endpoint.
    """
    ticker = ticker.strip().upper()

    # Check prediction cache first
    if ticker in _prediction_cache:
        ml_pred = _prediction_cache[ticker]
    else:
        df = download_ticker_data(ticker)
        if df is None or len(df) < 100:
            raise HTTPException(404, f"No data for {ticker}")
        ml_pred = model_manager.predict(df)
        _prediction_cache[ticker] = ml_pred

    ml_pred["ticker"] = ticker
    return ml_pred


@app.get("/api/available-tickers")
async def available_tickers():
    """Get list of all available F&O tickers for the analysis page dropdown."""
    tickers = get_fno_tickers()
    return {"tickers": tickers, "count": len(tickers)}


# ─────────────────────────────────────────────────────────────────
#  DASHBOARD (serve HTML)
# ─────────────────────────────────────────────────────────────────

@app.get("/", response_class=HTMLResponse)
async def dashboard():
    """Serve the ML Intelligence Dashboard."""
    dashboard_path = BASE_DIR / "ml_dashboard.html"
    if dashboard_path.exists():
        return dashboard_path.read_text(encoding="utf-8")
    return HTMLResponse("<h1>ML Service Running on Port 8001</h1><p>Dashboard file not found.</p>")


@app.get("/stock-analysis", response_class=HTMLResponse)
async def stock_analysis_page():
    """Serve the Per-Stock ML Analysis Dashboard."""
    analysis_path = BASE_DIR / "ml_stock_analysis.html"
    if analysis_path.exists():
        try:
            return analysis_path.read_text(encoding="utf-8")
        except UnicodeDecodeError:
            return analysis_path.read_text(encoding="latin-1")
    return HTMLResponse("<h1>Stock Analysis page not found.</h1>")


# ─────────────────────────────────────────────────────────────────
#  MAIN
# ─────────────────────────────────────────────────────────────────
if __name__ == "__main__":
    import uvicorn
    uvicorn.run(app, host="0.0.0.0", port=8001)